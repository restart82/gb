#!/bin/bash
for var in first second third fourth fifth
do
	echo The  $var item
done