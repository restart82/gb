#!/bin/bash
file="file_for_3.txt"
IFS=$'\n'
for var in $(cat $file)
do
echo " $var"
done