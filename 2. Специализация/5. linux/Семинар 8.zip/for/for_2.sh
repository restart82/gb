#!/bin/bash
for var in first "the second" "the third" "I’ll do it"
do
	echo "This is: $var"
done