#!/bin/bash
file="file_for_3.txt"
for var in $(cat $file)
do
echo " $var"
done