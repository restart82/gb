#!/bin/bash
echo Hello! > /tmp/script.txt
cat /tmp/script.txt